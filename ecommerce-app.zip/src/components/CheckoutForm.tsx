import React, { useState, useEffect } from 'react';

import { CardElement, useElements, useStripe } from '@stripe/react-stripe-js';
import { useSelector, useDispatch } from 'react-redux';
import { RootState } from '../app/store';
import { clearCart } from '../features/cart/cartSlice';
import { toast } from 'react-toastify';

const CheckoutForm: React.FC = () => {
  const stripe = useStripe();
  const elements = useElements();
  const cartItems = useSelector((state: RootState) => state.cart.items);
  const dispatch = useDispatch();
  const [loading, setLoading] = useState(false);
  const [clientSecret, setClientSecret] = useState('');

  useEffect(() => {
    const fetchClientSecret = async () => {
      try {
        const response = await fetch('http://localhost:4242/create-payment-intent', {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
          },
          body: JSON.stringify({ items: cartItems }),
        });

        if (!response.ok) {
          throw new Error('Failed to fetch client secret');
        }

        const data = await response.json();
        setClientSecret(data.clientSecret);
      } catch (error) {
        toast.error('An error occurred while fetching the client secret');
      }
    };

    fetchClientSecret();
  }, [cartItems]);

  const handleSubmit = async (event: React.FormEvent) => {
    event.preventDefault();

    if (!stripe || !elements || !clientSecret) {
      return;
    }

    setLoading(true);

    try {
      const result = await stripe.confirmCardPayment(clientSecret, {
        payment_method: {
          card: elements.getElement(CardElement)!,
        },
      });

      if (result.error) {
        toast.error(result.error.message || 'An error occurred');
      } else if (result.paymentIntent?.status === 'succeeded') {
        toast.success('Payment successful!');
        dispatch(clearCart());
      }
    } catch (error) {
      toast.error('An error occurred while processing the payment');
    }

    setLoading(false);
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-4">
      <CardElement className="p-2 border rounded" />
      <button
        type="submit"
        className="bg-green-500 text-white px-4 py-2 rounded mt-4 hover:bg-green-600 transition-colors duration-300"
        disabled={!stripe || loading}
      >
        {loading ? 'Processing...' : 'Confirm Purchase'}
      </button>
    </form>
  );
};

export default CheckoutForm;
